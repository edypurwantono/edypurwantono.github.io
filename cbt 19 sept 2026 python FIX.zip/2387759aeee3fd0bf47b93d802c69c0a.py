"""
EXAMGO — Server Pusat (Multi-User Cloud Sync)
Dibuat oleh Tim Pengembang IT SMAN 1 Leces
Penanggung jawab: Edy Purwantono, S.Pd., S.Kom., M.Pd.

APA INI:
Server kecil yang menyimpan SEMUA data EXAMGO (data guru, siswa, mata
pelajaran, bank soal, status pengawasan ujian, rekap nilai, konfigurasi
ujian) di satu tempat. Semua perangkat (komputer admin, guru, siswa) yang
menjalankan app.py akan membaca & menulis ke server ini lewat jaringan,
sehingga datanya benar-benar sama/tersinkron di semua perangkat.

CARA PAKAI:
1. Jalankan server ini HANYA DI SATU KOMPUTER (misalnya komputer admin/TU
   sekolah, yang menyala selama ujian berlangsung). Komputer ini akan
   menjadi "pusat data".
2. Install dulu (sekali saja):
       pip install flask flask-cors
3. Jalankan:
       python server.py
   Akan muncul tulisan "Running on http://0.0.0.0:5000" — itu tandanya
   server sudah aktif.
4. Cari tahu alamat IP komputer ini di jaringan sekolah (LAN/WiFi yang
   sama dengan komputer guru & siswa), misalnya dengan menjalankan
   "ipconfig" (Windows) dan melihat "IPv4 Address", contoh: 192.168.1.10
5. Di SETIAP komputer guru/siswa yang menjalankan app.py, buka aplikasi,
   klik ikon ⚙️ di layar login, lalu masukkan alamat:
       http://192.168.1.10:5000
   (ganti dengan IP komputer server yang sebenarnya), lalu Simpan.
6. Selesai — semua device sekarang berbagi data yang sama secara real-time
   (perangkat lain akan melihat perubahan data dalam beberapa detik).

CATATAN:
- Semua komputer WAJIB berada di jaringan WiFi/LAN yang sama dengan
  komputer server. Ini bukan server internet publik.
- Data disimpan sebagai file "examgo_data.json" di folder yang sama
  dengan server.py. Cadangkan (backup) file ini secara berkala.
- Kalau nanti ingin diakses lewat internet (bukan cuma LAN sekolah),
  server ini perlu di-hosting di VPS/cloud sungguhan (mis. lewat layanan
  hosting Python) dan dibuka portnya — itu langkah lanjutan terpisah.
"""

import json
import os
import threading
from datetime import datetime

from flask import Flask, jsonify, request
from flask_cors import CORS

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "examgo_data.json")

app = Flask(__name__)
CORS(app)  # izinkan diakses dari file HTML yang dibuka di pywebview/browser device lain

_lock = threading.Lock()

ALLOWED_KEYS = {
    "guruData", "siswaData", "mapelData", "bankSoalData",
    "proctorData", "rekapData", "examConfig",
}


def read_all():
    with _lock:
        if not os.path.exists(DATA_FILE):
            return {}
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}


def write_all(data):
    with _lock:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


@app.route("/api/ping", methods=["GET"])
def ping():
    return jsonify({"ok": True, "message": "Server EXAMGO aktif", "waktu": datetime.now().isoformat()})


@app.route("/api/state", methods=["GET"])
def get_state():
    """Ambil seluruh data bersama sekaligus (dipanggil saat aplikasi dibuka & polling berkala)."""
    return jsonify(read_all())


@app.route("/api/state/<key>", methods=["POST"])
def set_key(key):
    """Simpan satu jenis data (mis. guruData, siswaData, dst). Dipanggil setiap ada
    tambah/edit/hapus di aplikasi client."""
    if key not in ALLOWED_KEYS:
        return jsonify({"ok": False, "error": f"Key '{key}' tidak dikenal"}), 400
    payload = request.get_json(force=True, silent=True)
    if payload is None:
        return jsonify({"ok": False, "error": "Body harus JSON valid"}), 400

    data = read_all()
    data[key] = payload
    data["_lastUpdated"] = datetime.now().isoformat()
    write_all(data)
    return jsonify({"ok": True})


if __name__ == "__main__":
    print("=" * 60)
    print("EXAMGO SERVER PUSAT — SMAN 1 Leces")
    print("Data disimpan di:", DATA_FILE)
    print("Biarkan jendela ini tetap terbuka selama ujian berlangsung.")
    print("=" * 60)
    app.run(host="0.0.0.0", port=5000, debug=False)
