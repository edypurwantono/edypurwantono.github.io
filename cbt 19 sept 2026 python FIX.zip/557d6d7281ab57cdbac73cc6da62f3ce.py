"""
EXAMGO — CBT Anti Nyontek SMAN 1 Leces (versi Desktop Python / pywebview)
Dibuat oleh Tim Pengembang IT SMAN 1 Leces
Penanggung jawab: Edy Purwantono, S.Pd., S.Kom., M.Pd.

CARA PAKAI:
1. Pastikan file ini (app.py) dan index.html ada di FOLDER YANG SAMA.
2. Install pywebview sekali saja:
       pip install pywebview
   (di Windows, kalau muncul error render engine, tambahkan juga:
       pip install pywebview[cef]
   tapi untuk mayoritas komputer Windows 10/11 modern, EdgeChromium bawaan
   sudah cukup dan tidak perlu paket tambahan.)
3. Jalankan:
       python app.py
   Jendela aplikasi CBT akan terbuka menampilkan index.html.

TENTANG TOMBOL "TUTUP PROGRAM" SAAT UJIAN (anti-nyontek):
Saat siswa berpindah ke aplikasi/jendela lain ketika ujian berlangsung,
index.html akan menampilkan peringatan dengan 2 pilihan: "Lanjutkan ke Soal
Ujian" atau "Tutup Program". Tombol "Tutup Program" memanggil fungsi Python
close_app() di bawah ini (lewat window.pywebview.api) untuk benar-benar
menutup jendela aplikasi.

PENTING — BATASAN JUJUR YANG PERLU DIKETAHUI:
Ini TIDAK sama dengan mengunci komputer sepenuhnya atau mencegah siswa
membuka aplikasi lain di tingkat sistem operasi. Yang benar-benar bisa
dilakukan aplikasi berbasis web/pywebview seperti ini:
  - Mendeteksi saat jendela EXAMGO kehilangan fokus / disembunyikan
    (siswa pindah ke aplikasi lain / Alt+Tab / minimize), lalu menampilkan
    peringatan dan mencatatnya sebagai pelanggaran.
  - Menutup jendela EXAMGO itu sendiri kalau siswa memilih "Tutup Program".
Yang TIDAK bisa dilakukan tanpa software tambahan di luar Python biasa:
  - Mencegah siswa membuka aplikasi lain sama sekali (mis. mengunci
    Alt+Tab, Windows key, Task Manager secara sistem).
  - Mengunci seluruh layar komputer selain lewat jendela ini.
Untuk penguncian total tingkat sistem operasi (kiosk mode sungguhan),
diperlukan software terpisah seperti Safe Exam Browser, atau kebijakan
Windows (Group Policy / Assigned Access kiosk mode) yang dipasang oleh
admin IT di setiap komputer ujian — itu di luar cakupan skrip Python ini.

CATATAN LAIN:
- Data (guru, siswa, soal, nilai) sekarang tersinkron ke server pusat
  (server.py) lewat jaringan — lihat pengaturan ⚙️ di layar login untuk
  mengatur alamat server.
- Semua tombol unduh file (Template Word, Template Excel, Ekspor CSV, dsb)
  sekarang memakai dialog "Simpan Sebagai" asli Windows lewat fungsi
  save_file() di bawah — ini menggantikan mekanisme <a download> bawaan
  browser yang tidak selalu bekerja di jendela pywebview.
"""

import os
import sys
import webview


def resource_path(filename: str) -> str:
    """Cari file di folder yang sama dengan app.py (atau folder exe jika sudah dibundel)."""
    if getattr(sys, "frozen", False):
        base_dir = os.path.dirname(sys.executable)
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, filename)


class Api:
    """Dipanggil dari JavaScript lewat window.pywebview.api.<nama_fungsi>(...)"""

    def close_app(self):
        try:
            webview.windows[0].destroy()
        except Exception:
            os._exit(0)
        return True

    def save_file(self, filename, base64_data):
        """Menyimpan file (Template Word/Excel, Ekspor CSV, dsb) lewat dialog
        'Simpan Sebagai' asli Windows — dipakai karena tombol download bawaan
        browser (<a download>) tidak selalu berfungsi di jendela pywebview."""
        import base64
        try:
            result = webview.windows[0].create_file_dialog(
                webview.SAVE_DIALOG, save_filename=filename
            )
            if not result:
                return {"ok": False, "cancelled": True}
            path = result if isinstance(result, str) else result[0]
            raw = base64.b64decode(base64_data)
            with open(path, "wb") as f:
                f.write(raw)
            return {"ok": True, "path": path}
        except Exception as e:
            return {"ok": False, "error": str(e)}


def main():
    html_path = resource_path("index.html")
    api = Api()

    if not os.path.isfile(html_path):
        # Kalau index.html tidak ditemukan, tampilkan jendela pesan error yang jelas
        # alih-alih jendela kosong tanpa keterangan.
        error_html = f"""
        <html><body style="font-family:sans-serif;padding:40px;background:#0f172a;color:#fca5a5">
        <h2>⚠ index.html tidak ditemukan</h2>
        <p>Aplikasi mencari file di lokasi berikut, tapi tidak ada:</p>
        <code style="background:#1e293b;padding:8px 12px;border-radius:8px;display:inline-block">{html_path}</code>
        <p style="margin-top:16px;color:#cbd5e1">Pastikan file <b>index.html</b> berada di folder yang sama dengan <b>app.py</b>.</p>
        </body></html>
        """
        webview.create_window("EXAMGO — Error", html=error_html, width=700, height=350)
        webview.start()
        return

    webview.create_window(
        title="CBT Anti-Nyontek SMAN 1 Leces — EXAMGO",
        url=html_path,
        width=1360,
        height=860,
        min_size=(1024, 680),
        resizable=True,
        fullscreen=True,
        confirm_close=True,
        js_api=api,
    )
    # debug=False untuk mode normal. Ganti ke True sementara kalau perlu
    # membuka DevTools untuk menelusuri error JavaScript.
    webview.start(debug=False)


if __name__ == "__main__":
    main()
